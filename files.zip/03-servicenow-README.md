# ServiceNow Ticket Lifecycle — SOC Incident Documentation

**Platform:** ServiceNow Personal Developer Instance (PDI)  
**Scenario:** Phishing alert from Microsoft Sentinel → full ticket lifecycle  
**Purpose:** Demonstrate audit-ready SOC ticket documentation

---

## Overview

This folder documents the complete lifecycle of a security incident ticket
in ServiceNow, from initial creation through investigation notes to resolution.
The source alert is the Sentinel phishing investigation in folder 01.

---

## Ticket lifecycle stages

### Stage 1 — Ticket creation

**Fields completed on creation:**

| Field | Value |
|---|---|
| Category | Security |
| Subcategory | Phishing |
| Priority | 2 — High |
| Caller | SOC Analyst L1 |
| Short description | Suspected phishing — anomalous sign-in — user@domain.com |
| Assignment group | SOC Tier 1 |

*Screenshot: ticket creation — to be added*

---

### Stage 2 — Work notes (triage in progress)

Work notes are added at each step — these are internal analyst notes visible to
the SOC team, not the end user. Each note is timestamped.

**Work note 1 — Initial review:**
```
[Analyst] Sentinel incident #1234 assigned. Alert: Sign-in from anomalous
location for user@domain.com. IP: 185.220.x.x, Location: Romania.
User's normal location: California. Beginning log investigation.
```

**Work note 2 — KQL results:**
```
[Analyst] Ran KQL against SigninLogs (last 24h). Sign-in succeeded at 14:32 UTC.
ResultType: 0 (success). AuthenticationRequirement: singleFactorAuthentication —
MFA was NOT enforced on this sign-in. ConditionalAccess: notApplied.
Suspicious — escalating indicators noted.
```

**Work note 3 — Post-login activity check:**
```
[Analyst] Checked AuditLogs for post-login actions. Found: new MFA method
(authenticator app) added at 14:35 UTC from same IP. This indicates attacker
is attempting persistence. Escalating to Tier 2.
```

*Screenshots: work notes in ServiceNow — to be added*

---

### Stage 3 — Escalation to Tier 2

**Fields updated:**

| Field | Value |
|---|---|
| Priority | 1 — Critical |
| Assignment group | SOC Tier 2 |
| State | In progress |

**Escalation note:**
```
[Analyst] Escalating to Tier 2. Confirmed indicators of compromise:
- Successful sign-in from anomalous location (Romania)
- MFA bypassed (singleFactorAuthentication)
- Attacker added new MFA method at 14:35 UTC (persistence attempt)
- Recommended immediate actions: disable account, revoke sessions,
  remove attacker MFA method
Sentinel incident link: [URL]
```

*Screenshot: escalation handoff — to be added*

---

### Stage 4 — Resolution and closure

**Fields updated on closure:**

| Field | Value |
|---|---|
| State | Resolved |
| Resolution code | Solved (Security incident) |
| Resolved by | SOC Tier 2 |

**Resolution notes:**
```
Account disabled and sessions revoked at 15:10 UTC. Attacker MFA method removed.
Endpoint scan clean — no malware executed. User notified and credential reset
initiated. Phishing email purged from all mailboxes. Account re-enabled at
16:45 UTC after MFA re-registration confirmed. Monitoring for 72h.
Total MTTR: 38 minutes (alert to containment).
```

*Screenshot: closed ticket — to be added*

---

## What this demonstrates

- Understanding of ITSM ticket hygiene and SOC documentation standards
- Ability to write clear, timestamped work notes at each triage step
- Correct escalation procedure with evidence and recommended actions
- Audit-ready resolution notes including MTTR calculation
- Real-world ServiceNow field usage (priority, state, resolution code)
