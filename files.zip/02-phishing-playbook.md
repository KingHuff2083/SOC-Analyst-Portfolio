# Incident Response Playbook — Phishing with Credential Theft

**Framework:** NIST SP 800-61 Rev. 2  
**Scenario:** Phishing email → user clicks link → credentials harvested → attacker signs in  
**Analyst level:** Tier 1 / Tier 2  
**Last updated:** 2026

---

## Attack chain (MITRE ATT&CK)

| Stage | Technique ID | Technique name | Detection source |
|---|---|---|---|
| Initial access | T1566.001 | Spearphishing attachment | Email gateway / Defender |
| Execution | T1204.002 | User execution — malicious file | Defender for Endpoint |
| Credential access | T1056.001 | Keylogging / credential harvest | Endpoint telemetry |
| Valid accounts | T1078 | Use of harvested credentials | SigninLogs — anomalous location |
| Persistence | T1098 | Account manipulation | AuditLogs — MFA method added |

---

## Phase 1 — Preparation

**Before an incident occurs, confirm the following are in place:**

- [ ] Microsoft Sentinel connected to Azure AD SigninLogs and AuditLogs
- [ ] Defender for Endpoint deployed on all managed endpoints
- [ ] Email gateway alerts feeding into Sentinel (Defender for Office 365)
- [ ] On-call escalation contact list is current (Tier 2 lead, IR manager)
- [ ] Incident ticket template ready in ServiceNow (Category: Security, Subcategory: Phishing)

---

## Phase 2 — Detection and analysis

**Tier 1 analyst actions:**

1. Alert fires in Sentinel — review incident entities (user, IP, email sender, attachment hash)
2. Run KQL to confirm sign-in succeeded and check for impossible travel:

```kql
SigninLogs
| where TimeGenerated > ago(1h)
| where UserPrincipalName == "<affected_user>"
| project TimeGenerated, IPAddress, Location, ResultType,
          ConditionalAccessStatus, AuthenticationRequirement
| order by TimeGenerated desc
```

3. Check if MFA was satisfied or bypassed:

```kql
SigninLogs
| where UserPrincipalName == "<affected_user>"
| where TimeGenerated > ago(24h)
| where AuthenticationRequirement == "singleFactorAuthentication"
```

4. Look for post-login activity (new MFA methods, mail rules, OAuth grants):

```kql
AuditLogs
| where TimeGenerated > ago(24h)
| where InitiatedBy.user.userPrincipalName == "<affected_user>"
| where OperationName in (
    "Update user", "Add app role assignment",
    "Set force change user password", "Update StsRefreshTokenValidFrom")
| project TimeGenerated, OperationName, Result, TargetResources
```

5. Check endpoint for malware execution (if device is known):

```kql
DeviceProcessEvents
| where DeviceName == "<device_name>"
| where TimeGenerated > ago(2h)
| where InitiatingProcessFileName !in ("explorer.exe", "chrome.exe", "msedge.exe")
| project TimeGenerated, FileName, ProcessCommandLine, InitiatingProcessFileName
```

**Severity determination:**

| Condition | Severity |
|---|---|
| Credentials used, MFA bypassed, post-login activity detected | Critical — escalate immediately |
| Credentials used, MFA passed, no follow-on activity | Medium — monitor and contain |
| Phishing email delivered, not clicked | Low — awareness notification |

---

## Phase 3 — Containment

**Tier 1 actions (execute immediately on confirmed compromise):**

- [ ] Isolate endpoint in Defender for Endpoint → Device page → Isolate device
- [ ] Disable user account in Azure AD (Entra ID) → Users → Block sign-in
- [ ] Revoke all active sessions: `Revoke sign-in sessions` in Entra ID user blade
- [ ] Block sender domain in Defender for Office 365 → Tenant Allow/Block List
- [ ] Preserve evidence: export incident timeline from Sentinel before any remediation

**Escalate to Tier 2 if:**
- Attacker has added persistence (new MFA method, OAuth app, mail forwarding rule)
- Multiple users affected
- Privileged account (admin, service account) is involved

---

## Phase 4 — Eradication

*(Tier 2 / IR team lead)*

- [ ] Remove malicious emails from all mailboxes (Purge in Defender for Office 365)
- [ ] Delete any OAuth app grants made by the attacker
- [ ] Remove any mail forwarding rules added by attacker
- [ ] Remove any new MFA methods added by attacker
- [ ] Reset user credentials and force MFA re-registration
- [ ] Patch or re-image endpoint if malware was executed

---

## Phase 5 — Recovery

- [ ] Re-enable user account after credential reset confirmed
- [ ] Lift device isolation after clean EDR scan
- [ ] Verify Conditional Access policies require MFA for the affected user
- [ ] Notify user with security awareness reminder
- [ ] Monitor account for 72 hours post-recovery for re-compromise

---

## Phase 6 — Post-incident activity

- [ ] Document full timeline: first alert → containment → recovery
- [ ] Calculate MTTR (mean time to respond)
- [ ] Identify detection gap: was the phishing email caught before delivery?
- [ ] Update Sentinel analytics rule if detection was delayed
- [ ] Submit lessons learned to security team weekly standup
- [ ] File post-incident report in ServiceNow within 5 business days

---

## Ticket documentation template

```
Short description: Suspected phishing — credential compromise — <username>

Description:
Alert fired in Microsoft Sentinel at <time> flagging anomalous sign-in for <user>.
Investigation confirmed successful authentication from <country> at <time>.
MFA status: [bypassed / satisfied]. Post-login activity: [none / list actions].

Actions taken:
1. Reviewed Sentinel incident and entity map
2. Ran KQL against SigninLogs — confirmed sign-in from <IP> / <location>
3. Checked AuditLogs — [no post-login activity / found: <action>]
4. [Isolated endpoint / Disabled account / Revoked sessions]
5. Escalated to Tier 2: [yes / no] — reason: <reason>

Resolution: [Pending Tier 2 / Closed — false positive / Contained]
```
