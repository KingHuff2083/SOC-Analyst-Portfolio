# Sentinel Investigation — Suspicious Sign-in from Anomalous Location

> **Status:** In progress — Azure lab being configured  
> **Tool:** Microsoft Sentinel (Training Lab solution)  
> **Severity:** Medium  
> **Outcome:** TBD after lab completion

---

## Overview

This investigation documents a triage walkthrough of a Microsoft Sentinel alert
flagging a suspicious sign-in from an unusual geographic location. The goal is
to demonstrate the end-to-end Tier 1 analyst workflow: alert review, log
investigation, KQL querying, finding determination, and escalation decision.

---

## Alert details

| Field | Value |
|---|---|
| Alert name | Sign-in from anomalous location |
| Severity | Medium |
| MITRE tactic | Initial Access |
| MITRE technique | T1078 — Valid Accounts |
| Log source | SigninLogs (Azure AD) |
| Assigned to | KingHuff2083 |

---

## Investigation steps

### Step 1 — Review the alert in Sentinel

- Opened the incident in Microsoft Sentinel → Incidents blade
- Reviewed entities: user principal name, source IP, location
- Noted sign-in was from a country outside the user's normal pattern

### Step 2 — Query SigninLogs with KQL

```kql
SigninLogs
| where TimeGenerated > ago(7d)
| where UserPrincipalName == "user@domain.com"
| project TimeGenerated, UserPrincipalName, IPAddress, Location,
          ResultType, AppDisplayName, ConditionalAccessStatus
| order by TimeGenerated desc
```

*Screenshot of query results will be added after lab completion.*

### Step 3 — Check for MFA and Conditional Access

```kql
SigninLogs
| where UserPrincipalName == "user@domain.com"
| where TimeGenerated > ago(24h)
| summarize
    SuccessCount = countif(ResultType == 0),
    FailureCount = countif(ResultType != 0),
    Locations = make_set(Location),
    IPs = make_set(IPAddress)
  by UserPrincipalName
```

### Step 4 — Check for lateral movement or follow-on activity

```kql
AuditLogs
| where TimeGenerated > ago(24h)
| where InitiatedBy.user.userPrincipalName == "user@domain.com"
| project TimeGenerated, OperationName, Result, TargetResources
| order by TimeGenerated desc
```

---

## Findings

> *To be completed after running the Sentinel Training Lab.*

Preliminary assessment based on alert metadata:

- Sign-in succeeded (ResultType = 0) — credentials were valid
- Location flagged as anomalous by Sentinel ML model
- MFA status and Conditional Access outcome to be confirmed in logs

---

## Escalation decision

| Decision | Reasoning |
|---|---|
| ☐ True positive — escalate to Tier 2 | If MFA was bypassed or impossible travel confirmed |
| ☐ False positive — close | If user travel confirmed via HR / manager |
| ☐ Benign positive — monitor | If MFA passed and no follow-on activity |

---

## Screenshots

*To be added after Azure lab deployment:*
- [ ] Sentinel incident view
- [ ] KQL query results in Log Analytics
- [ ] Entity map showing user + IP + location

---

## What this demonstrates

- Ability to navigate Microsoft Sentinel and work an incident from the queue
- KQL proficiency for log investigation
- Structured triage methodology aligned with NIST SP 800-61
- Clear escalation reasoning documented in audit-ready format
