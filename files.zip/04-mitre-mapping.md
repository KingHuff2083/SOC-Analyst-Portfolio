# MITRE ATT&CK Mapping — Phishing to Account Takeover

**Framework version:** ATT&CK v14  
**Scenario:** Phishing email → credential harvest → account takeover → persistence  
**Purpose:** Map a real-world attack chain to ATT&CK techniques and document
detection and mitigation for each stage

---

## Attack narrative

An attacker sends a targeted phishing email to a corporate user. The email
contains a link to a credential harvesting page spoofing the company's
Microsoft 365 login portal. The user enters credentials. The attacker
immediately uses the credentials to sign in from an overseas IP, bypasses MFA
by replaying an already-authenticated session token (AiTM), adds a new MFA
method for persistence, and creates a mail forwarding rule to exfiltrate email.

---

## Technique mapping

### T1566.001 — Phishing: Spearphishing link

**Tactic:** Initial Access  
**What happened:** Attacker sent email with link to fake M365 login page

**Detection:**
- Defender for Office 365 — Safe Links policy blocks known malicious URLs
- Email gateway logs — sender domain age, SPF/DKIM/DMARC failures
- KQL — hunt for links to newly registered domains in email telemetry

```kql
EmailUrlInfo
| where TimeGenerated > ago(24h)
| join kind=inner EmailEvents on NetworkMessageId
| where Url contains "login" and UrlDomain !endswith "microsoft.com"
| project TimeGenerated, SenderFromAddress, RecipientEmailAddress, Url, UrlDomain
```

**Mitigation:** M1017 — User training; M1054 — Safe Links policy enforcement

---

### T1078 — Valid Accounts

**Tactic:** Initial Access, Persistence, Defense Evasion  
**What happened:** Attacker authenticated using harvested credentials

**Detection:**
- SigninLogs — anomalous location, new IP, impossible travel
- Sentinel analytics rule — "Sign-in from IP address marked as risky"
- KQL — compare current sign-in location vs. historical baseline

```kql
let user = "user@domain.com";
let historical_locations = SigninLogs
    | where TimeGenerated between (ago(30d) .. ago(1d))
    | where UserPrincipalName == user
    | summarize HistoricalLocations = make_set(Location);
SigninLogs
| where TimeGenerated > ago(1h)
| where UserPrincipalName == user
| where Location !in (historical_locations)
| project TimeGenerated, UserPrincipalName, IPAddress, Location, ResultType
```

**Mitigation:** M1032 — MFA; M1036 — Account use policies; Conditional Access

---

### T1111 — Multi-Factor Authentication Interception (AiTM)

**Tactic:** Credential Access  
**What happened:** Attacker used adversary-in-the-middle proxy to steal session
token, bypassing MFA entirely

**Detection:**
- SigninLogs — `AuthenticationRequirement: singleFactorAuthentication` on a
  user who should require MFA
- Risky sign-in in Entra ID Identity Protection

```kql
SigninLogs
| where TimeGenerated > ago(24h)
| where AuthenticationRequirement == "singleFactorAuthentication"
| where UserPrincipalName in (
    AADUserRiskEvents | where RiskLevel == "high" | distinct UserPrincipalName)
| project TimeGenerated, UserPrincipalName, IPAddress, Location
```

**Mitigation:** M1032 — Phishing-resistant MFA (FIDO2 / Windows Hello);
Conditional Access with sign-in risk policy

---

### T1098.005 — Account Manipulation: Device Registration

**Tactic:** Persistence  
**What happened:** Attacker registered a new MFA authenticator app to maintain
access after password reset

**Detection:**
- AuditLogs — `Add authentication method` operation shortly after sign-in
- Sentinel analytics rule — MFA method added from new device/IP

```kql
AuditLogs
| where TimeGenerated > ago(24h)
| where OperationName == "User registered security info"
| extend IP = tostring(AdditionalDetails[0].value)
| project TimeGenerated, TargetResources[0].userPrincipalName, OperationName, IP
```

**Mitigation:** M1026 — Privileged account management; require TAP for MFA
registration; alert on all new MFA method additions

---

### T1114.003 — Email Collection: Email Forwarding Rule

**Tactic:** Collection  
**What happened:** Attacker created inbox rule to forward all email to
external address for ongoing exfiltration

**Detection:**
- AuditLogs — `New-InboxRule` or `Set-InboxRule` operation
- Defender for Office 365 — anomalous forwarding rule alert

```kql
AuditLogs
| where TimeGenerated > ago(24h)
| where OperationName in ("New-InboxRule", "Set-InboxRule")
| extend ForwardTo = tostring(AdditionalDetails)
| where ForwardTo contains "ForwardTo" or ForwardTo contains "RedirectTo"
| project TimeGenerated, TargetResources[0].userPrincipalName, OperationName, ForwardTo
```

**Mitigation:** M1047 — Audit (alert on all new forwarding rules);
block external forwarding via Exchange transport rules

---

## ATT&CK coverage summary

| Technique | Tactic | Detected by | KQL query | Mitigation |
|---|---|---|---|---|
| T1566.001 | Initial Access | Defender for O365 | ✅ | Safe Links + training |
| T1078 | Initial Access | Sentinel / SigninLogs | ✅ | MFA + Conditional Access |
| T1111 | Credential Access | Identity Protection | ✅ | FIDO2 / phishing-resistant MFA |
| T1098.005 | Persistence | AuditLogs | ✅ | MFA registration policy |
| T1114.003 | Collection | AuditLogs | ✅ | Block external forwarding |

---

## Key takeaway for detection engineering

The weakest link in this chain is T1111 (AiTM). Standard TOTP-based MFA does
not protect against session token theft. The only reliable mitigation is
phishing-resistant MFA (FIDO2 security keys or Windows Hello for Business),
which cannot be intercepted by an AiTM proxy because authentication is bound
to the origin URL.

This is a detection gap in many organizations — and a strong discussion point
in a SOC analyst or detection engineer interview.
